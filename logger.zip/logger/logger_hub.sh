#!/bin/bash
# --------------------------------------------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------------------------------------------
DATE=$(date +%Y.%m.%d_%H..%M..%S)
DEFNAME=$DATE.Hub.USB

# default folder:>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
LOG=~/Log/
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

GREEN='\033[0;32m'  #  ${GREEN}
LGREEN='\033[1;32m' #  ${LGREEN}
RED='\033[0;31m'    #  ${RED}
LRED='\033[1;31m'   #  ${LRED}
NORMAL='\033[0m'    #  ${NORMAL}

# --------------------------------------------------------------------------------------------------------------
# menu
# --------------------------------------------------------------------------------------------------------------
menu() {

  Infa=$(ls /dev/ttyUSB* | cut -c 12-)

  masDev=()
  k=0
  for myUsedDev in ${Infa}; do
    masDev[$k]=$myUsedDev
    k+=1
  done

  myUsed=()
  i=0
  for myConnDev in ${Infa}; do

    myUsed[$i]=$(lsof /dev/ttyUSB$myConnDev 2>/dev/null | grep -w "PID")
    i+=1
  done

  clear
  echo -e ""
  echo -e "                                ${LGREEN}Hub logger AJAX${NORMAL}"
  echo -e "                       ${GREEN}115200 speed (Skuridin S. mod v.X.8)${NORMAL}"
  echo -e ""

  echo -e "Available ports for logging:"

  for muUsed in ${!myUsed[*]}; do

    if [ -z "${myUsed[$muUsed]}" ]; then
      echo -e "${LGREEN}USB"${masDev[$muUsed]}" free${NORMAL}"
    else
      echo -e "${RED}USB"${masDev[$muUsed]}" used${NORMAL}"
    fi
  done

  echo -e ""

  ChoosePort
  RestartLog

}

# --------------------------------------------------------------------------------------------------------------
# ChoosePort
# --------------------------------------------------------------------------------------------------------------
ChoosePort() {
  echo -n "What port do you want to log /dev/ttyUSB_ :> "
  read CHOISE
  echo -e ""
  if ! [[ "${CHOISE}" =~ (^[0-9]+$) ]]; then
    echo -e "${LRED}Invalid port number!\n${NORMAL}"
    exit
  else
    for muUsed in ${!LoggedPort[*]}; do
      PortNumber="${masDev[$muUsed]}"                                                 # Port number.
      if [ -n "${LoggedPort[$muUsed]}" ] && [ "${CHOISE}" -eq "${PortNumber}" ]; then # If the selected port is used.
        echo -e "${LRED}Select a free port.\n${NORMAL}"
        exit
      elif ! (echo "${Infa}" | grep -oq "${CHOISE}"); then # If the selected port is not connected.
        echo -e "${LRED}This port is not connected.\n${NORMAL}"
        exit
      fi
    done
  fi
}

# --------------------------------------------------------------------------------------------------------------
# Start Log minicom
# --------------------------------------------------------------------------------------------------------------
StartLog() {
  DATE=$(date +%d.%m.%Y_%H:%M:%S)
  DEFNAME=$DATE.Hub.USB
  PUT="$LOG$NAME$DEFNAME$CHOISE.txt"
  nohup konsole -p tabtitle="Port USB "$CHOISE -e "minicom -b 115200  -D /dev/ttyUSB$CHOISE -c on -C \"$LOG\"\"$NAME\"$DEFNAME$CHOISE'.txt'"
  sleep 0.5
  printf "\r\n" >/dev/ttyUSB$CHOISE
  sleep 1
  printf "\r\n" >/dev/ttyUSB$CHOISE
}

# --------------------------------------------------------------------------------------------------------------
# Restart Log
# --------------------------------------------------------------------------------------------------------------
RestartLog() {
  StartLog
  sleep 2
  printf "\r\n" >/dev/ttyUSB$CHOISE

  printf "\r\n" >/dev/ttyUSB$CHOISE
  sleep 10
  echo -e "${LRED} \nDo not close this window to auto-restart logging.\n ${NORMAL}"
  sleep 10

  while [ 1 ]; do
    MyFileSize=$(wc -c "$PUT" | awk '{print $1}')
    PIDStartLog=$(lsof "$PUT" | grep -w minicom | awk '{print $2}')
    #		TimeNow=`date +%H`
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if [[ $(lsof "$PUT" | grep -w "minicom") ]]; then
      #				if (( $TimeNow>=1 ))
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
      if (($MyFileSize > 80000000)); then
        $(kill $PIDStartLog)
        sleep 7
        StartLog
        echo -e "${LGREEN}Logging has been restarted in:\n${NORMAL}$PUT"
        sleep 10
      fi
    else
      echo -e "${LRED} \nYou closed the minicom, autostart logging is disabled.\n ${NORMAL}"
      exit
    fi
    sleep 10
  done
}

menu
