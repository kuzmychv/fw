sudo apt install konsole -y
sudo apt install minicom -y
sudo apt install git -y
sudo snap install notepad-plus-plus
sudo apt install build-essential -y
sudo apt install autoconf -y
sudo apt install autotools-dev -y
sudo apt install automake -y
sudo apt install libtool -y
sudo apt install libgimp2.0-dev -y
sudo apt install gimp-plugin-registry -y
sudo apt install libncurses5-dev -y
sudo apt install libncursesw5-dev -y

mkdir -p ~/AJAX-SOFT/Logger
cp ./logger_hub.sh ~/AJAX-SOFT/Logger/


echo "alias logger='~/AJAX-SOFT/Logger/logger_hub.sh'" >> ~/.bashrc
source ~/.bashrc

cd minicom-v2.7.2_default_timestamp/
make clean
./autogen.sh
./configure
make
sudo make install
cd ../

mkdir -p ~/Log/


sudo adduser `whoami` dialout
sudo adduser `whoami` plugdev
